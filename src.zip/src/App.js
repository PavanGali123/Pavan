import logo from'./logo.svg';
import './app.css';
import './css/custom.css';
import navbar from './components/navbar';
import content from './components/content';
import sidebar from './components/sidebar';

function app(){
    return(
        <div classname="app">

        <div>
            <navbar />
            <content />
            <sidebar />
        </div>
      </div>
    );
}

export default app;